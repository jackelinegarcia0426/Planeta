/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package planeta;

/**
 *
 * @author estudiante307
 */
public class Planeta {

    // Atributos del planeta
    private final String nombre;
    private final int cantidadSatelites;
    private final double masa; // en kilogramos
    private final double volumen; // en metros cúbicos
    private final double diametro; // en kilómetros
    private final double distanciaAlSol; // en kilómetros
    private final boolean esObservable;

    // Constructor para inicializar los valores del planeta
    public Planeta(String nombre, int cantidadSatelites, double masa, double volumen, double diametro, double distanciaAlSol, boolean esObservable) {
        this.nombre = nombre;
        this.cantidadSatelites = cantidadSatelites;
        this.masa = masa;
        this.volumen = volumen;
        this.diametro = diametro;
        this.distanciaAlSol = distanciaAlSol;
        this.esObservable = esObservable;
    }

    // Método para calcular la densidad del planeta (masa / volumen)
    public double calcularDensidad() {
        return masa / volumen;
    }

    // Método para imprimir los valores de los atributos del planeta
    public void imprimirAtributos() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Cantidad de Satélites: " + cantidadSatelites);
        System.out.println("Masa: " + masa + " kg");
        System.out.println("Volumen: " + volumen + " m³");
        System.out.println("Diámetro: " + diametro + " km");
        System.out.println("Distancia al Sol: " + distanciaAlSol + " km");
        System.out.println("Es observable: " + (esObservable ? "Sí" : "No"));
        System.out.println("Densidad: " + calcularDensidad() + " kg/m³");
    }

    // Método main para crear objetos y ejecutar el programa
    public static void main(String[] args) {
        // Creación de los objetos Planeta
        Planeta p1 = new Planeta("Tierra", 1, 5.9736E24, 1.08321E12, 12742, 150000000, true);
        Planeta p2 = new Planeta("Jupiter", 1, 1.899E27, 1.4313E15, 139820, 750000000, true);

        // Imprimir atributos de los planetas
        System.out.println("Datos del Planeta 1 (Tierra):");
        p1.imprimirAtributos();

        System.out.println("\nDatos del Planeta 2 (Jupiter):");
        p2.imprimirAtributos();
    }
}
